
import UploadableMap from './UploadableMap';

import "@fontsource/vazir";
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles.css'

import './GeoProject.css';
const GeoProject = () => {

    return(
        <div className='GeoProject'>


            
            <br/> 
            <UploadableMap/>
            <br/>
            
        </div>
    )
}   

export default GeoProject;